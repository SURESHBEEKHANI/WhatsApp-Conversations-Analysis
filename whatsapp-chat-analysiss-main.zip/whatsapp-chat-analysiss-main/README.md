# whatsapp-chat-analysis
A streamlit app to analyze your whatsapp chats

Demo Link: https://wca-campusx.herokuapp.com/
